package beans;

import java.io.Serializable;

public class ItemBean implements Serializable {

	private String itemID; //商品ID
	private String itemName; //商品名
	private int itemPrice; //価格
	private int itemNewPrice; //新価格

	//引数無しコンストラクタ(引数有りを作った場合は作る)
	public ItemBean() {
	}

	//引数有りコンストラクタ(ID、名前、価格)
	public ItemBean(String itemID, String itemName, int itemPrice) {
		this.itemID = itemID;
		this.itemName =itemName;
		this.itemPrice = itemPrice;
	}

	public String getItemID() {
		return itemID;
	}

	public void setItemID(String itemID) {
		this.itemID = itemID;
	}

	public String getItemName() {
		return itemName;
	}

	public void setItemName(String itemName) {
		this.itemName = itemName;
	}

	public int getItemPrice() {
		return itemPrice;
	}

	public void setItemPrice(int itemPrice) {
		this.itemPrice = itemPrice;
	}

	public int getItemNewPrice() {
		return itemNewPrice;
	}

	public void setItemNewPrice(int itemNewPrice) {
		this.itemNewPrice = itemNewPrice;
	}

}
