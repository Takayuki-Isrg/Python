package model;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;

import beans.ItemBean;

public class ItemLogic {

	//itemMap(HashMap)を属性値にする
	private LinkedHashMap<String, ItemBean> itemMap;

	//コンストラクタ LinkedHashMap(key,商品オブジェクト)の初期化
	public ItemLogic() {
		this.itemMap = new LinkedHashMap<String, ItemBean>();
	}

	//itemIDをキーにして商品登録
	public void putItem(ItemBean itemBean) {
		itemMap.put(itemBean.getItemID(), itemBean);
	}

	//削除する商品一覧を取得する
	public ArrayList<ItemBean> getDeleteList(Map<String, String[]> deleteItemMap) {

		//商品一覧の初期化
		ArrayList<ItemBean> deleteItemList = new ArrayList<ItemBean>();

		//登録されている商品のHashMapを取得
		HashMap<String, ItemBean> itemMap = this.itemMap;

		//Mapを拡張for文で表示
		for (String key : deleteItemMap.keySet()) {

			//削除チェックが入っている場合
			if (!deleteItemMap.get(key)[0].isBlank()) {
				//keyをコンソール表示
				//System.out.println(key);
				//該当のItemBeanを取得して
				ItemBean itemBean = itemMap.get(key);
				//新しいItemBeanをリストにセット
				deleteItemList.add(itemBean);
			}
		}
		return deleteItemList;
	}

	//削除リストから新しいitemMapを作る
	public void deleteItem(ArrayList<ItemBean> deleteList) {

		//登録されている商品のitemMapを取得
		LinkedHashMap<String, ItemBean> itemMap = this.itemMap;

		//拡張for文で削除チェックが入った商品を除く
		for (ItemBean itemBean : deleteList) {
			itemMap.remove(itemBean.getItemID());
		}
		//新しいitemMapを作成
		this.itemMap = itemMap;
	}

	//価格変更する商品一覧を取得する
	public ArrayList<ItemBean> getChangePriceList(Map<String, String[]> changeItemMap) {

		//商品一覧の初期化
		ArrayList<ItemBean> changeItemList = new ArrayList<ItemBean>();

		//登録されている商品のHashMapを取得
		HashMap<String, ItemBean> itemMap = this.itemMap;

		//Mapを拡張for文で表示
		for (String key : changeItemMap.keySet()) {
			//新価格が入力されている場合
			if (!changeItemMap.get(key)[0].isBlank()) {
				int itemNewPrice = Integer.parseInt(changeItemMap.get(key)[0]);
				//keyと新価格をコンソール表示
				//System.out.println("key:" + key +":value:" + itemNewPrice);
				//該当のItemBeanを取得して
				ItemBean itemBean = itemMap.get(key);
				//新価格をセットする
				itemBean.setItemNewPrice(itemNewPrice);
				//新しいItemBeanをリストにセット
				changeItemList.add(itemBean);
			}
		}
		return changeItemList;
	}

	//価格変更リストから新しいitemMapを作る
	public void changePrice(ArrayList<ItemBean> changeList) {

		//登録されている商品のitemMapを取得
		LinkedHashMap<String, ItemBean> itemMap = this.itemMap;

		//拡張for文で価格を変更
		for (ItemBean itemBean : changeList) {
			ItemBean newItemBean = itemMap.get(itemBean.getItemID());
			newItemBean.setItemPrice(newItemBean.getItemNewPrice());
			itemMap.put(itemBean.getItemID(), newItemBean);
		}
		//新しいitemMapを作成
		this.itemMap = itemMap;
	}

	public LinkedHashMap<String, ItemBean> getItemMap() {
		return itemMap;
	}

	public void setItemMap(LinkedHashMap<String, ItemBean> itemMap) {
		this.itemMap = itemMap;
	}

}
