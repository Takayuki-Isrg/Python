package controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import beans.ItemBean;
import model.ItemLogic;

/**
 * Servlet implementation class DeleteConfirm
 */
@WebServlet("/DeleteConfirm")
public class DeleteConfirm extends HttpServlet {
	private static final long serialVersionUID = 1L;

    /**
     * @see HttpServlet#HttpServlet()
     */
    public DeleteConfirm() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//文字コード設定
		request.setCharacterEncoding("UTF-8");
		response.setCharacterEncoding("UTF-8");

		//リクエストよりパラメーターのMapを取得
		Map<String, String[]> deleteItemMap = request.getParameterMap();

		//セッションの取得
		HttpSession session = request.getSession();
		//セッションから商品ロジックをゲット
		ItemLogic itemLogic = (ItemLogic) session.getAttribute("itemLogic");

		//削除リストの作成
		ArrayList<ItemBean> deleteList = itemLogic.getDeleteList(deleteItemMap);

		//セッションに削除リストを追加
		session.setAttribute("deleteList", deleteList);
		//ページの転送
		request.getRequestDispatcher("/WEB-INF/DeleteConfirm.jsp").forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
