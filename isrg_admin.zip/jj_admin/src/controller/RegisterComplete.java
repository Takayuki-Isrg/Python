package controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import beans.ItemBean;
import model.ItemLogic;

/**
 * Servlet implementation class RegisterComplete
 */
@WebServlet("/RegisterComplete")
public class RegisterComplete extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public RegisterComplete() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		//		response.getWriter().append("Served at: ").append(request.getContextPath());
		//ページの転送

	//文字コード設定
	request.setCharacterEncoding("UTF-8");response.setCharacterEncoding("UTF-8");

	//変数の宣言
	ItemBean itemBean; //商品オブジェクト
	ItemLogic itemLogic; //商品ロジック(管理)

	//セッションの取得
	HttpSession session = request.getSession();
	//セッションから商品オブジェクトをゲット
	itemBean=(ItemBean)session.getAttribute("itemBean");
	//セッションから商品ロジックをゲット
	itemLogic=(ItemLogic)session.getAttribute("itemLogic");

	//商品ロジックがnull(未作成)の場合、新規作成
	if(itemLogic==null)
	{
		itemLogic = new ItemLogic();
	}

	//商品ロジックに商品オブジェクトの追加
	itemLogic.putItem(itemBean);

	//セッションに商品ロジックを追加
	session.setAttribute("itemLogic",itemLogic);

	request.getRequestDispatcher("/WEB-INF/Complete.jsp").forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
