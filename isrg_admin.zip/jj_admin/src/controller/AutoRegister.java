package controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import beans.ItemBean;
import model.ItemLogic;

/**
 * Servlet implementation class AutoRegister
 */
@WebServlet("/AutoRegister")
public class AutoRegister extends HttpServlet {
	private static final long serialVersionUID = 1L;

    /**
     * @see HttpServlet#HttpServlet()
     */
    public AutoRegister() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//セッションの取得
		HttpSession session = request.getSession();
		//セッションから商品ロジックをゲット
		ItemLogic itemLogic = (ItemLogic) session.getAttribute("itemLogic");

		//商品ロジックがnull(未作成)の場合、新規作成
		if (itemLogic == null) {

		//商品オブジェクトの生成
		ItemBean itemBean1 = new ItemBean("0001","PINGライバー",38500);
		ItemBean itemBean2 = new ItemBean("0002","エピックドライバー",67600);
		ItemBean itemBean3 = new ItemBean("0003","ストロークラボBlack",17600);
		ItemBean itemBean4 = new ItemBean("0004","セレクトニューポート",60500);
		ItemBean itemBean5 = new ItemBean("0005","ホワイトホット",10500);

		//商品ロジックに商品オブジェクトを追加
		itemLogic = new ItemLogic();
		itemLogic.putItem(itemBean1);
		itemLogic.putItem(itemBean2);
		itemLogic.putItem(itemBean3);
		itemLogic.putItem(itemBean4);
		itemLogic.putItem(itemBean5);

		//セッションに商品ロジックを追加
		session.setAttribute("itemLogic", itemLogic);
		}

		//ページの転送
		request.getRequestDispatcher("/WEB-INF/List.jsp")
		.forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
